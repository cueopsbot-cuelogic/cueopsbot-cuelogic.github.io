#!/bin/bash

npm install -g wizzy

git clone <repo>

cd <Monitoring and Logging repo>

Deploy Logging and Monitoring stacks

Confirm stack is up and running

fetch grafana Host url

#Initiate wizzy

wizzy init

#configure wizzy

wizzy set grafana url GRAFANA_URL
wizzy set grafana username YOUR_USERNAME  // values should come from ENV Variables
wizzy set grafana password YOUR_PASSWORD  // values should come from ENV Variables

# check wizzy status

wizzy status

# if everything is fine export dashboards and datasources
wizzy export dashboard // to export all the dashboards
wizzy export dashboard DASHBOARD_SLUG  // to export single dashboard
wizzy export datasources   // to export all the datasources
wizzy export datasource DATASOURCE_NAME

# After configuring wizzy make sure to put conf file in gitignore

Configure datasources:

curl http://admin:test2@172.21.31.198:3000/api/datasources -X POST -H 'Content-Type: application/json;charset=UTF-8' -d @datasources/Elasticsearch.json
curl http://admin:test2@172.21.31.198:3000/api/datasources -X POST -H 'Content-Type: application/json;charset=UTF-8' -d @datasources/Prometheus.json

Confgure dashboards:

curl -H 'Content-Type:application/json' -X POST -d @../grafana-wizzy/dashboards/cueops-monitoring.json http://admin:test2@172.21.31.198:3000/api/dashboards/db

